"use client"

import { useState } from "react"
import { MessageSquare, Video, Users } from "lucide-react"
import AskCoach from "@/components/ask-coach"
import Videos from "@/components/videos"
import RolePlay from "@/components/role-play"
import LoginPage from "@/components/login-page"

export default function Home() {
  const [showLogin, setShowLogin] = useState(true)
  const [activeTab, setActiveTab] = useState<"coach" | "videos" | "roleplay">("coach")

  if (showLogin) {
    return <LoginPage onLogin={() => setShowLogin(false)} />
  }

  return (
    <div className="flex flex-col h-screen bg-background">
      <nav className="sticky top-0 z-10 bg-card border-b border-border">
        <div className="flex items-center justify-around h-14 max-w-lg mx-auto">
          <button
            onClick={() => setActiveTab("coach")}
            className={`flex items-center gap-2 px-6 py-2 transition-colors ${
              activeTab === "coach" ? "text-primary" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            <span className="text-sm font-medium">Ask Coach</span>
          </button>

          <button
            onClick={() => setActiveTab("videos")}
            className={`flex items-center gap-2 px-6 py-2 transition-colors ${
              activeTab === "videos" ? "text-primary" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Video className="w-5 h-5" />
            <span className="text-sm font-medium">Videos</span>
          </button>

          <button
            onClick={() => setActiveTab("roleplay")}
            className={`flex items-center gap-2 px-6 py-2 transition-colors ${
              activeTab === "roleplay" ? "text-primary" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="text-sm font-medium">Role Play</span>
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        {activeTab === "coach" && <AskCoach />}
        {activeTab === "videos" && <Videos />}
        {activeTab === "roleplay" && <RolePlay />}
      </main>
    </div>
  )
}
