import { Card } from "@/components/ui/card"
import { Play, Clock, TrendingUp } from "lucide-react"

const videos = [
  {
    id: 1,
    title: "Mastering Cold Calls",
    duration: "12:34",
    thumbnail: "/sales-professional-phone-call.jpg",
    views: "2.3K",
  },
  {
    id: 2,
    title: "Closing Techniques That Work",
    duration: "8:45",
    thumbnail: "/business-handshake-deal.jpg",
    views: "1.8K",
  },
  {
    id: 3,
    title: "Building Client Relationships",
    duration: "15:20",
    thumbnail: "/business-meeting-discussion.jpg",
    views: "3.1K",
  },
  {
    id: 4,
    title: "Objection Handling Strategies",
    duration: "10:15",
    thumbnail: "/sales-presentation-training.jpg",
    views: "1.5K",
  },
  {
    id: 5,
    title: "Revenue Growth Masterclass",
    duration: "18:30",
    thumbnail: "/business-growth-chart.jpg",
    views: "4.2K",
  },
  {
    id: 6,
    title: "Advanced Negotiation Skills",
    duration: "14:55",
    thumbnail: "/executive-negotiation-meeting.jpg",
    views: "2.7K",
  },
]

export default function Videos() {
  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-2">
        <TrendingUp className="w-5 h-5 text-primary" />
        <h2 className="text-xl font-bold">Sales Training Videos</h2>
      </div>

      {/* Video Grid */}
      <div className="grid grid-cols-1 gap-4">
        {videos.map((video) => (
          <Card key={video.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative">
              <img src={video.thumbnail || "/placeholder.svg"} alt={video.title} className="w-full h-48 object-cover" />
              <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                <div className="w-16 h-16 rounded-full bg-primary/90 flex items-center justify-center">
                  <Play className="w-8 h-8 text-primary-foreground ml-1" fill="currentColor" />
                </div>
              </div>
              <div className="absolute bottom-2 right-2 bg-black/80 text-white px-2 py-1 rounded text-xs font-medium flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {video.duration}
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-base mb-1 line-clamp-2">{video.title}</h3>
              <p className="text-sm text-muted-foreground">{video.views} views</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
