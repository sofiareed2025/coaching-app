"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Send, Sparkles } from "lucide-react"

export default function AskCoach() {
  const [question, setQuestion] = useState("")
  const [messages, setMessages] = useState<Array<{ role: "user" | "coach"; text: string }>>([
    {
      role: "coach",
      text: "Hey there! I'm your sales and business coach. Ask me anything about closing deals, building client relationships, business strategy, or growing your revenue. Let's crush your goals! 🚀",
    },
  ])

  const handleSend = () => {
    if (!question.trim()) return

    setMessages([...messages, { role: "user", text: question }])

    // Simulate coach response
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          role: "coach",
          text: "Great question! Let me help you with that. Remember, success in sales is about building genuine relationships and providing value. Keep pushing forward and stay focused on your prospects' needs!",
        },
      ])
    }, 1000)

    setQuestion("")
  }

  return (
    <div className="flex flex-col h-full">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message, index) => (
          <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
            <Card
              className={`max-w-[80%] p-4 ${
                message.role === "user" ? "bg-primary text-primary-foreground" : "bg-card"
              }`}
            >
              {message.role === "coach" && (
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-accent" />
                  <span className="text-sm font-semibold text-accent">Coach</span>
                </div>
              )}
              <p className="text-sm leading-relaxed">{message.text}</p>
            </Card>
          </div>
        ))}
      </div>

      {/* Input Area */}
      <div className="p-4 bg-card border-t border-border">
        <div className="flex gap-2 max-w-lg mx-auto">
          <Textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask your coach anything..."
            className="min-h-[50px] max-h-[120px] resize-none"
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                handleSend()
              }
            }}
          />
          <Button onClick={handleSend} size="icon" className="h-[50px] w-[50px] shrink-0" disabled={!question.trim()}>
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  )
}
