import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, Trophy, Target, Zap } from "lucide-react"

const scenarios = [
  {
    id: 1,
    title: "Discovery Call Practice",
    description: "Master the art of asking the right questions to uncover client needs",
    icon: Trophy,
    difficulty: "Beginner",
    color: "text-accent",
  },
  {
    id: 2,
    title: "Handling Price Objections",
    description: "Learn to confidently address pricing concerns and demonstrate value",
    icon: Target,
    difficulty: "Intermediate",
    color: "text-primary",
  },
  {
    id: 3,
    title: "Executive Sales Presentation",
    description: "Present to C-level executives with confidence and impact",
    icon: Users,
    difficulty: "Advanced",
    color: "text-secondary",
  },
  {
    id: 4,
    title: "Closing the Deal",
    description: "Practice closing techniques and asking for the business",
    icon: Zap,
    difficulty: "Intermediate",
    color: "text-accent",
  },
]

export default function RolePlay() {
  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Users className="w-5 h-5 text-primary" />
          <h2 className="text-xl font-bold">Role Play Scenarios</h2>
        </div>
        <p className="text-sm text-muted-foreground">Practice real-world situations in a safe environment</p>
      </div>

      {/* Scenarios */}
      <div className="space-y-4">
        {scenarios.map((scenario) => {
          const Icon = scenario.icon
          return (
            <Card key={scenario.id} className="p-5 hover:shadow-md transition-shadow">
              <div className="flex items-start gap-4">
                <div className={`p-3 rounded-xl bg-muted ${scenario.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-base">{scenario.title}</h3>
                    <span className="text-xs font-medium px-2 py-1 rounded-full bg-primary/10 text-primary">
                      {scenario.difficulty}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{scenario.description}</p>
                  <Button className="w-full sm:w-auto">Start Scenario</Button>
                </div>
              </div>
            </Card>
          )
        })}
      </div>

      {/* Stats Card */}
      <Card className="p-5 bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20">
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <Trophy className="w-5 h-5 text-primary" />
          Your Progress
        </h3>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-2xl font-bold text-primary">12</p>
            <p className="text-xs text-muted-foreground">Completed</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-accent">8</p>
            <p className="text-xs text-muted-foreground">In Progress</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-secondary">4</p>
            <p className="text-xs text-muted-foreground">Mastered</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
